package com.megaIT.book.springboot.config.auth;


import java.lang.annotation.ElementType;
import java.lang.annotation.Retention;
import java.lang.annotation.RetentionPolicy;
import java.lang.annotation.Target;

@Target(ElementType.PARAMETER)
@Retention(RetentionPolicy.RUNTIME) // 프로그램 돌아갈 때 실행한다.
public @interface LoginUser { //@interface 어노테이션 클래스 지정
}
